/*
 * ArithmeticMapper.h -- C versions of ArithmeticMapper.java's classes
 * (NativeEncoder). So far the range coder, as ArithmeticMapper.RangeEncoder
 * and RangeDecoder: the same bytes for the same calls, and back.
 */
#ifndef ARITHMETIC_MAPPER_H
#define ARITHMETIC_MAPPER_H

#include <stddef.h>
#include <stdint.h>

/* ArithmeticMapper.CONTEXT_INCREMENT, CONTEXT_LIMIT: the context models'
   steps (counts from 1, + the increment per symbol, halved past the limit). */
#define CONTEXT_INCREMENT 32
#define CONTEXT_LIMIT     (1 << 16)

/* ArithmeticMapper.RangeEncoder. */
typedef struct RangeEncoder
{
	uint8_t *out;            /* the bytes written so far (grown as needed) */
	size_t   size, capacity;
	int64_t  low, range;     /* the interval's bottom and width */
	int      cache;          /* the byte held back until a carry can no longer change it */
	int64_t  cache_size;     /* the held byte plus the 0xFF bytes after it */
	int      failed;         /* out of memory */
} RangeEncoder;

/* An encoder with an empty interval; n is the expected size in bytes (a hint).
   Returns 0, or -1 if out of memory. */
int  RangeEncoder_init(RangeEncoder *e, size_t n);
void RangeEncoder_free(RangeEncoder *e);
/* Narrows the interval to [start, start + count) out of total (under 2^30). */
void RangeEncoder_encode(RangeEncoder *e, int64_t start, int64_t count, int64_t total);
/* Flushes the interval; the coded bytes are then out[0 .. size). Returns 0,
   or -1 if it ran out of memory on the way. */
int  RangeEncoder_finish(RangeEncoder *e);

/* ArithmeticMapper.RangeDecoder, reading coded bytes that have all arrived
   (past their end it reads zeros, as the Java does). */
typedef struct RangeDecoder
{
	const uint8_t *in;
	size_t   length, pos;   /* pos starts at 1: the first byte written is always the initial cache */
	int64_t  code, range, r;
} RangeDecoder;

void RangeDecoder_init(RangeDecoder *d, const uint8_t *in, size_t length);
/* The count the next symbol's interval holds, out of total. */
int  RangeDecoder_target(RangeDecoder *d, int64_t total);
/* Takes the interval [start, start + count) found from target's count. */
void RangeDecoder_decode(RangeDecoder *d, int64_t start, int64_t count);

#endif
