@echo off
rem The benchmarks from the command line (Eclipse: the RowFitBench,
rem bench_RowFit, CoderBench and DecoderBench launches): the fit in Java, in C
rem through JNI and in the C programs, then the coder, then the decoder, in
rem Java and in C, checking they agree.
rem   native\run_bench.bat image [quant shift runs]
rem Uses MSYS2's ucrt64 (gcc, mingw32-make) in C:\msys64\ucrt64; set MINGW
rem first if it's elsewhere, e.g. set MINGW=D:\msys64\ucrt64
rem Results go to the window and to bench_results.txt here. It builds the
rem library DeltaMapper too (NativeWriter's C), which RowFitBench times.
setlocal
cd /d "%~dp0"
if "%~1"=="" (echo usage: native\run_bench.bat image [quant shift runs] & exit /b 1)
set Q=%2& set SH=%3& set RUNS=%4
if "%Q%"=="" set Q=4
if "%SH%"=="" set SH=3
if "%RUNS%"=="" set RUNS=5
if not exist "%~f1" (echo No image %~f1 & exit /b 1)
rem Java 17 and later warn when a library is loaded unless native access is
rem enabled; Java 8 doesn't know the option, so it's only given if accepted.
set NA=
java --enable-native-access=ALL-UNNAMED -version >nul 2>&1 && set NA=--enable-native-access=ALL-UNNAMED
if "%MINGW%"=="" set MINGW=C:\msys64\ucrt64
if not exist "%MINGW%\bin\gcc.exe" (echo No gcc in %MINGW%\bin: install MSYS2's ucrt64 gcc, or set MINGW & exit /b 1)
rem gcc's own programs (cc1, as, ld) need the DLLs in ucrt64\bin.
set PATH=%MINGW%\bin;%PATH%
rem The library DeltaMapper needs the JDK's headers: JAVA_HOME, or else the
rem JDK the java command runs.
if not defined JAVA_HOME for /f "tokens=2 delims==" %%h in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr /c:"java.home ="') do set "JAVA_HOME=%%h"
for /f "tokens=* delims= " %%h in ("%JAVA_HOME%") do set "JAVA_HOME=%%h"
if not exist "%JAVA_HOME%\include\jni.h" (echo No JDK headers in "%JAVA_HOME%\include": set JAVA_HOME to a JDK's folder & exit /b 1)
"%MINGW%\bin\mingw32-make.exe" -s MINGW="%MINGW:\=/%" || exit /b 1
if not exist classes mkdir classes
javac --release 8 -nowarn -Xlint:-options -Xlint:-unchecked -encoding UTF-8 -d classes ..\java\src\*.java ..\java\bench\*.java || exit /b 1
(
java %NA% -Xms4g -Xmx4g -XX:+AlwaysPreTouch -cp classes RowFitBench "%~f1" rowfit.dump %Q% %SH% %RUNS%
echo.
echo bench_RowFit, -O3:
bench_RowFit.exe rowfit.dump %NUMBER_OF_PROCESSORS% %RUNS%
echo.
echo bench_RowFit_native, -O3 -march=native:
bench_RowFit_native.exe rowfit.dump %NUMBER_OF_PROCESSORS% %RUNS%
echo.
java %NA% -Xms4g -Xmx4g -XX:+AlwaysPreTouch -cp classes CoderBench "%~f1" %Q% %SH% %RUNS%
echo.
java %NA% -Xms4g -Xmx4g -XX:+AlwaysPreTouch -cp classes DecoderBench "%~f1" %Q% %SH% %RUNS%
) > bench_results.txt 2>&1
type bench_results.txt
