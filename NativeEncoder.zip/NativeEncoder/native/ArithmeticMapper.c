/*
 * ArithmeticMapper.c -- C versions of ArithmeticMapper.java's classes
 * (NativeEncoder). See ArithmeticMapper.h. Each function follows the Java
 * method of the same name.
 */
#include "ArithmeticMapper.h"

#include <stdlib.h>

#define RANGE_TOP    ((int64_t) 1 << 40)
#define RANGE_BOTTOM ((int64_t) 1 << 32)

int RangeEncoder_init(RangeEncoder *e, size_t n)
{
	e->capacity   = n + n / 4 + 16;
	if(e->capacity < 16) e->capacity = 16;
	e->out        = malloc(e->capacity);
	e->size       = 0;
	e->low        = 0;
	e->range      = RANGE_TOP - 1;
	e->cache      = 0;
	e->cache_size = 1;
	e->failed     = (e->out == NULL);
	return e->failed ? -1 : 0;
}

void RangeEncoder_free(RangeEncoder *e)
{
	free(e->out);
	e->out = NULL;
}

/* Appends a byte to the output, growing the buffer as needed. */
static void put(RangeEncoder *e, int b)
{
	if(e->size == e->capacity)
	{
		uint8_t *bigger = e->failed ? NULL : realloc(e->out, e->capacity * 2);
		if(bigger == NULL) { e->failed = 1; return; }
		e->out = bigger;
		e->capacity *= 2;
	}
	e->out[e->size++] = (uint8_t) b;
}

/* Shifts the top byte of low out (into the cache, or the output once it can
   no longer change). */
static void shiftLow(RangeEncoder *e)
{
	if(e->low < 0xFF00000000LL || e->low >= RANGE_TOP)
	{
		int carry = (int) ((uint64_t) e->low >> 40);
		int temp  = e->cache;
		do
		{
			put(e, temp + carry);
			temp = 0xFF;
		}
		while(--e->cache_size != 0);
		e->cache = (int) (((uint64_t) e->low >> 32) & 0xFF);
	}
	e->cache_size++;
	e->low = (e->low & 0xFFFFFFFFLL) << 8;
}

void RangeEncoder_encode(RangeEncoder *e, int64_t start, int64_t count, int64_t total)
{
	int64_t r = e->range / total;
	e->low  += start * r;
	e->range = count * r;
	while(e->range < RANGE_BOTTOM)
	{
		e->range <<= 8;
		shiftLow(e);
	}
}

int RangeEncoder_finish(RangeEncoder *e)
{
	for(int k = 0; k < 6; k++) shiftLow(e);
	return e->failed ? -1 : 0;
}

static inline int next_byte(RangeDecoder *d) { return (d->pos < d->length) ? d->in[d->pos++] : 0; }

void RangeDecoder_init(RangeDecoder *d, const uint8_t *in, size_t length)
{
	d->in = in; d->length = length; d->pos = 1;
	d->code = 0; d->range = RANGE_TOP - 1; d->r = 0;
	for(int k = 0; k < 5; k++) d->code = (d->code << 8) | next_byte(d);
}

int RangeDecoder_target(RangeDecoder *d, int64_t total)
{
	d->r = d->range / total;
	int64_t t = d->code / d->r;
	return (int) ((t < total - 1) ? t : total - 1);
}

void RangeDecoder_decode(RangeDecoder *d, int64_t start, int64_t count)
{
	d->code -= start * d->r;
	d->range = count * d->r;
	while(d->range < RANGE_BOTTOM)
	{
		d->range <<= 8;
		d->code = (d->code << 8) | next_byte(d);
	}
}
