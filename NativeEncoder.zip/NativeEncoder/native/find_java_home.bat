@echo off
rem Prints the folder of the JDK the java command runs (its java.home), for
rem the Makefile when JAVA_HOME is not set.
for /f "tokens=2 delims==" %%h in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr /c:"java.home ="') do for /f "tokens=* delims= " %%i in ("%%h") do echo %%i
