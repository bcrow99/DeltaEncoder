/*
 * bench_RowFit.c -- the C half of the RowFit benchmark (RowFitBench.java is
 * the Java half).
 *
 * Reads RowFitBench's dump (the channels and Java's predictions), fits each
 * channel with DeltaMapper.c's RowFit_plane, checks every prediction is the
 * same as the Java's, and prints the times: on the threads asked for (as the
 * writer runs it, bands of rows at the same time), on one thread, and on one
 * thread split into its parts. Each is the best of the runs.
 *
 *   bench_RowFit dump [threads runs]
 *
 * threads defaults to the number of cores, runs to 5.
 */
#include "DeltaMapper.h"

#include <float.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
static int cores(void) { SYSTEM_INFO s; GetSystemInfo(&s); return (int) s.dwNumberOfProcessors; }
#else
#include <unistd.h>
static int cores(void) { return (int) sysconf(_SC_NPROCESSORS_ONLN); }
#endif

static int32_t get32(const unsigned char *p) { return (int32_t) ((uint32_t) p[0] | (uint32_t) p[1] << 8 | (uint32_t) p[2] << 16 | (uint32_t) p[3] << 24); }
static int16_t get16(const unsigned char *p) { return (int16_t) ((uint16_t) p[0] | (uint16_t) p[1] << 8); }

int main(int argc, char **argv)
{
	if(argc < 2) { printf("Usage: bench_RowFit dump [threads runs]\n"); return 1; }
	int threads = (argc > 2) ? atoi(argv[2]) : cores();
	int runs    = (argc > 3) ? atoi(argv[3]) : 5;

	FILE *in = fopen(argv[1], "rb");
	if(!in) { printf("Can't open %s\n", argv[1]); return 1; }
	unsigned char head[24];
	if(fread(head, 1, 24, in) != 24 || memcmp(head, "RFB1", 4)) { printf("%s is not a RowFitBench dump\n", argv[1]); return 1; }
	int xdim = get32(head + 4), ydim = get32(head + 8), radius = get32(head + 12), every = get32(head + 16), channels = get32(head + 20);
	size_t n = (size_t) xdim * ydim;
	int32_t **v = calloc(channels, sizeof *v);
	int16_t **java = calloc(channels, sizeof *java);
	int16_t *out = malloc(n * sizeof *out);
	unsigned char *buf = malloc(n * 4);
	for(int i = 0; i < channels; i++)
	{
		v[i] = malloc(n * sizeof **v); java[i] = malloc(n * sizeof **java);
		if(fread(buf, 4, n, in) != n) { printf("%s ends early\n", argv[1]); return 1; }
		for(size_t k = 0; k < n; k++) v[i][k] = get32(buf + 4 * k);
		if(fread(buf, 2, n, in) != n) { printf("%s ends early\n", argv[1]); return 1; }
		for(size_t k = 0; k < n; k++) java[i][k] = get16(buf + 2 * k);
	}
	fclose(in);

	printf("RowFit benchmark (C, %d threads): %d x %d, radius %d, every %d, best of %d runs\n", threads, xdim, ydim, radius, every, runs);
	const char *name[] = {"green", "blue-green", "red-green"};
	double sum_all = 0, sum_one = 0;
	int bad = 0;
	printf("  channel      %2d threads    1 thread   (columns    solves  predictions)   ms\n", threads);
	for(int i = 0; i < channels; i++)
	{
		const int32_t *ref = (i > 0) ? v[i - 1] : NULL;
		double all = DBL_MAX, one = DBL_MAX;
		RowFitTimes best = { DBL_MAX, DBL_MAX, DBL_MAX };
		for(int run = 0; run < runs; run++)
		{
			double t0 = DeltaMapper_seconds();
			if(RowFit_plane(v[i], ref, xdim, ydim, radius, every, out, threads, NULL)) { printf("out of memory\n"); return 1; }
			double t1 = DeltaMapper_seconds();
			if(memcmp(out, java[i], n * sizeof *out))
			{
				size_t k = 0;
				while(out[k] == java[i][k]) k++;
				printf("  %s: %d threads: the predictions differ from the Java's, first at (%d, %d): %d, not %d\n", name[i], threads, (int) (k / xdim), (int) (k % xdim), out[k], java[i][k]);
				bad = 1;
			}
			RowFit_plane(v[i], ref, xdim, ydim, radius, every, out, 1, NULL);
			double t2 = DeltaMapper_seconds();
			if(memcmp(out, java[i], n * sizeof *out)) { printf("  %s: 1 thread: the predictions differ from the Java's\n", name[i]); bad = 1; }
			RowFitTimes part = { 0, 0, 0 };
			RowFit_plane(v[i], ref, xdim, ydim, radius, every, out, 1, &part);
			if(t1 - t0 < all) all = t1 - t0;
			if(t2 - t1 < one) one = t2 - t1;
			if(part.columns < best.columns) best.columns = part.columns;
			if(part.solves < best.solves) best.solves = part.solves;
			if(part.predictions < best.predictions) best.predictions = part.predictions;
		}
		printf("  %-10s %10.1f  %10.1f   (%8.1f  %8.1f  %8.1f)\n", (i < 3) ? name[i] : "?", all * 1e3, one * 1e3, best.columns * 1e3, best.solves * 1e3, best.predictions * 1e3);
		sum_all += all; sum_one += one;
	}
	printf("  %-10s %10.1f  %10.1f\n", "total", sum_all * 1e3, sum_one * 1e3);
	printf(bad ? "The C's predictions DIFFER from the Java's.\n" : "The C's predictions are the same as the Java's.\n");
	return bad;
}
