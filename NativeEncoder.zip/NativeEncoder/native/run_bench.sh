#!/bin/bash
# The benchmarks from the command line (Eclipse: the RowFitBench,
# bench_RowFit, CoderBench and DecoderBench launches): the fit in Java, in C
# through JNI and in the C programs, then the coder, then the decoder, in
# Java and in C, checking they agree.
#   native/run_bench.sh image [quant shift runs]
set -e
cd "$(dirname "$0")"
[ -n "$1" ] || { echo "usage: native/run_bench.sh image [quant shift runs]"; exit 1; }
IMAGE="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"; Q=${2:-4}; SH=${3:-3}; RUNS=${4:-5}
[ -f "$IMAGE" ] || { echo "No image $IMAGE"; exit 1; }
# Java 17 and later warn when a library is loaded unless native access is
# enabled; Java 8 doesn't know the option, so it's only given if accepted.
NA=; java --enable-native-access=ALL-UNNAMED -version >/dev/null 2>&1 && NA=--enable-native-access=ALL-UNNAMED
make -s
mkdir -p classes
javac --release 8 -nowarn -Xlint:-options -Xlint:-unchecked -encoding UTF-8 -d classes ../java/src/*.java ../java/bench/*.java
{
java $NA -Xms4g -Xmx4g -XX:+AlwaysPreTouch -cp classes RowFitBench "$IMAGE" rowfit.dump $Q $SH $RUNS
echo; echo "bench_RowFit, -O3:"; ./bench_RowFit rowfit.dump $(nproc) $RUNS
echo; echo "bench_RowFit_native, -O3 -march=native:"; ./bench_RowFit_native rowfit.dump $(nproc) $RUNS
echo; java $NA -Xms4g -Xmx4g -XX:+AlwaysPreTouch -cp classes CoderBench "$IMAGE" $Q $SH $RUNS
echo; java $NA -Xms4g -Xmx4g -XX:+AlwaysPreTouch -cp classes DecoderBench "$IMAGE" $Q $SH $RUNS
} 2>&1 | grep -v "Picked up" | tee bench_results.txt
