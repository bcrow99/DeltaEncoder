import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.file.*;

/**
 * The Java half of the RowFit benchmark (see bench_RowFit.c for the C half).
 * <p>
 * Quantizes an image as NativeWriter does (Pixel Resolution, centred
 * resizing, Color Resolution; the channels green, blue-green, red-green),
 * then times DeltaMapper.RowFit's fit of each channel in Java, with
 * NativeWriter.RADIUS and NativeWriter.EVERY: planeJava() as the writer runs it
 * (bands of rows on every core), the same on one thread, and on one thread
 * split into its parts (the column updates, the solves, the predictions).
 * Each is the best of the runs after a warm-up. If the library DeltaMapper
 * is found (DeltaMapper.NATIVE), it times the C's plane through JNI, as
 * NativeWriter calls it, and checks its predictions are the same. Then it
 * writes the channels and their predictions to a file that bench_RowFit
 * reads, to check its predictions are the same and time them.
 *
 * <pre>
 * java -cp &lt;classes&gt; RowFitBench image dump [quant shift runs]
 * </pre>
 * The defaults are Save's (Pixel Resolution 4, Color Resolution 3) and 5 runs.
 */
public class RowFitBench
{
	/** Not instantiated: everything is static. */
	private RowFitBench() { }

	/**
	 * Runs the benchmark.
	 *
	 * @param args the image, the dump file, then optionally the Pixel
	 *             Resolution, the Color Resolution and the number of runs
	 * @throws Exception if the image can't be read or the dump written
	 */
	public static void main(String[] args) throws Exception
	{
		if(args.length < 2) { System.out.println("Usage: java RowFitBench image dump [quant shift runs]"); return; }
		int quant = (args.length > 2) ? Integer.parseInt(args[2]) : 4;
		int shift = (args.length > 3) ? Integer.parseInt(args[3]) : 3;
		int runs  = (args.length > 4) ? Integer.parseInt(args[4]) : 5;

		java.awt.image.BufferedImage image = ViewerSupport.readImage(args[0]);
		int xdim = image.getWidth(), ydim = image.getHeight();
		int[] pixel = image.getRGB(0, 0, xdim, ydim, null, 0, xdim);
		int[][] bgr = new int[3][pixel.length];
		for(int k = 0; k < pixel.length; k++) { bgr[0][k] = pixel[k] & 0xff; bgr[1][k] = (pixel[k] >> 8) & 0xff; bgr[2][k] = (pixel[k] >> 16) & 0xff; }
		int[] size = DeltaMapper.getQuantizedSize(xdim, ydim, quant);
		int w = size[0], h = size[1];
		int[][] q = new int[3][];
		for(int i = 0; i < 3; i++)
		{
			int[] c = (quant != 0) ? ResizeMapper.resize2(bgr[i], xdim, w, h) : bgr[i];
			q[i] = DeltaMapper.quantizeChannel(c, shift);
		}
		int[] min = new int[6];
		int[][] qc = DeltaMapper.getCandidateChannels(q[0], q[1], q[2], min);
		int[][] value = new int[3][];
		for(int i = 0; i < 3; i++) value[i] = qc[NativeWriter.CHANNELS[i]];
		int radius = NativeWriter.RADIUS, every = NativeWriter.EVERY;
		System.out.println(String.format("RowFit benchmark (Java %s, %d cores): %s, Pixel Resolution %d, Color Resolution %d: %d x %d, radius %d, every %d, best of %d runs",
			System.getProperty("java.version"), Runtime.getRuntime().availableProcessors(), new File(args[0]).getName(), quant, shift, w, h, radius, every, runs));

		short[][] out = new short[3][];
		double[] all = new double[3], one = new double[3], cols = new double[3], solves = new double[3], preds = new double[3];
		for(int i = 0; i < 3; i++)
		{
			int[] v = value[i], ref = (i > 0) ? value[i - 1] : null;
			all[i] = one[i] = cols[i] = solves[i] = preds[i] = Double.MAX_VALUE;
			for(int run = 0; run < runs + 2; run++)   // the first two warm up
			{
				long t0 = System.nanoTime();
				short[] p = DeltaMapper.RowFit.planeJava(v, ref, w, h, radius, every, new short[v.length], Runtime.getRuntime().availableProcessors());
				long t1 = System.nanoTime();
				short[] s = serial(v, ref, w, h, radius, every, null);
				long t2 = System.nanoTime();
				double[] part = new double[3];
				serial(v, ref, w, h, radius, every, part);
				if(!java.util.Arrays.equals(p, s)) throw new IllegalStateException("plane and serial differ");
				out[i] = p;
				if(run < 2) continue;
				all[i] = Math.min(all[i], (t1 - t0) / 1e9);
				one[i] = Math.min(one[i], (t2 - t1) / 1e9);
				cols[i] = Math.min(cols[i], part[0]); solves[i] = Math.min(solves[i], part[1]); preds[i] = Math.min(preds[i], part[2]);
			}
		}
		String[] name = {"green", "blue-green", "red-green"};
		System.out.println("  channel      all cores    1 thread   (columns    solves  predictions)   ms");
		for(int i = 0; i < 3; i++)
			System.out.println(String.format("  %-10s %10.1f  %10.1f   (%8.1f  %8.1f  %8.1f)", name[i], all[i] * 1e3, one[i] * 1e3, cols[i] * 1e3, solves[i] * 1e3, preds[i] * 1e3));
		System.out.println(String.format("  %-10s %10.1f  %10.1f", "total", (all[0] + all[1] + all[2]) * 1e3, (one[0] + one[1] + one[2]) * 1e3));

		System.out.println("The C through JNI: " + DeltaMapper.NATIVE_STATUS);
		if(DeltaMapper.NATIVE)
		{
			int threads = Runtime.getRuntime().availableProcessors();
			double[] c_all = new double[3], c_one = new double[3];
			boolean same = true;
			for(int i = 0; i < 3; i++)
			{
				int[] v = value[i], ref = (i > 0) ? value[i - 1] : null;
				c_all[i] = c_one[i] = Double.MAX_VALUE;
				short[] p = new short[v.length];
				for(int run = 0; run < runs + 1; run++)   // the first warms up
				{
					long t0 = System.nanoTime();
					int r0 = DeltaMapper.rowFitPlane(v, ref, w, h, radius, every, p, threads);
					long t1 = System.nanoTime();
					same &= (r0 == 0) && java.util.Arrays.equals(p, out[i]);
					int r1 = DeltaMapper.rowFitPlane(v, ref, w, h, radius, every, p, 1);
					long t2 = System.nanoTime();
					same &= (r1 == 0) && java.util.Arrays.equals(p, out[i]);
					if(run < 1) continue;
					c_all[i] = Math.min(c_all[i], (t1 - t0) / 1e9);
					c_one[i] = Math.min(c_one[i], (t2 - t1) / 1e9);
				}
			}
			System.out.println("  channel      all cores    1 thread    (C through JNI)   ms");
			for(int i = 0; i < 3; i++)
				System.out.println(String.format("  %-10s %10.1f  %10.1f", name[i], c_all[i] * 1e3, c_one[i] * 1e3));
			System.out.println(String.format("  %-10s %10.1f  %10.1f", "total", (c_all[0] + c_all[1] + c_all[2]) * 1e3, (c_one[0] + c_one[1] + c_one[2]) * 1e3));
			System.out.println(same ? "The C's predictions are the same as the Java's." : "The C's predictions DIFFER from the Java's.");
		}

		// The dump, little-endian: "RFB1", width, height, radius, every, 3
		// channels; then per channel its values (int32) and the predictions
		// (int16). Channel i > 0 fits from channel i - 1.
		int n = w * h;
		ByteBuffer b = ByteBuffer.allocate(24 + 3 * n * 6).order(ByteOrder.LITTLE_ENDIAN);
		b.put(new byte[] {'R', 'F', 'B', '1'}).putInt(w).putInt(h).putInt(radius).putInt(every).putInt(3);
		for(int i = 0; i < 3; i++)
		{
			for(int x : value[i]) b.putInt(x);
			for(short x : out[i]) b.putShort(x);
		}
		b.flip();
		try(FileChannel fc = FileChannel.open(Paths.get(args[1]), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) { while(b.hasRemaining()) fc.write(b); }
		System.out.println("Wrote " + args[1]);
	}

	/**
	 * The fit on one thread, as one band (the same predictions as plane:
	 * each band's sums are exact); with part, the time in each part, in
	 * seconds: the column updates, the solves, the predictions.
	 *
	 * @param v      the channel
	 * @param ref    the previous channel, or null
	 * @param xdim   the width
	 * @param ydim   the height
	 * @param radius the window radius
	 * @param every  how often along a row the fit is solved
	 * @param part   if not null, gets the time in each part
	 * @return the predictions
	 */
	static short[] serial(int[] v, int[] ref, int xdim, int ydim, int radius, int every, double[] part)
	{
		short[] out = new short[v.length];
		if(ydim < 2) return out;
		DeltaMapper.RowFit f = new DeltaMapper.RowFit(v, ref, xdim, radius, every);
		f.start(1);
		long c = 0, s = 0, p = 0;
		for(int y = 1; y < ydim; y++)
		{
			long t0 = (part != null) ? System.nanoTime() : 0;
			f.moveTo(y, false);
			long t1 = (part != null) ? System.nanoTime() : 0;
			f.solveRow(y, false);
			long t2 = (part != null) ? System.nanoTime() : 0;
			for(int x = 1; x < xdim - 1; x++) out[y * xdim + x] = (short) f.predict(y, x);
			if(part != null) { long t3 = System.nanoTime(); c += t1 - t0; s += t2 - t1; p += t3 - t2; }
		}
		if(part != null) { part[0] = c / 1e9; part[1] = s / 1e9; part[2] = p / 1e9; }
		return out;
	}
}
